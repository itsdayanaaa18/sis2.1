package com.company;

import java.io.Serializable;

public abstract class Shape implements Serializable {
    public abstract double calculateArea();
}