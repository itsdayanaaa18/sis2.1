package com.company;

import com.company.Shape;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientApp {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 12345;

        try (Socket socket = new Socket(host, port);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to server.");

            while (true) {
                System.out.println("Choose a shape: (1) com.company.Circle, (2) com.company.Rectangle, or 'Q' to quit:");
                String choice = scanner.nextLine();

                if (choice.equalsIgnoreCase("Q")) {
                    System.out.println("Exiting...");
                    break;
                }

                Shape shape = null;
                switch (choice) {
                    case "1":
                        System.out.print("Enter radius of the circle: ");
                        double radius = Double.parseDouble(scanner.nextLine());
                        shape = new Circle(radius);
                        break;
                    case "2":
                        System.out.print("Enter width of the rectangle: ");
                        double width = Double.parseDouble(scanner.nextLine());
                        System.out.print("Enter height of the rectangle: ");
                        double height = Double.parseDouble(scanner.nextLine());
                        shape = new Rectangle(width, height);
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                        continue;
                }


                objectOutputStream.writeObject(shape);


                String response = (String) objectInputStream.readObject();
                System.out.println("Server response: " + response);
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}