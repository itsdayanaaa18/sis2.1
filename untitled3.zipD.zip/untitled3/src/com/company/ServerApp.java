package com.company;

import com.company.Shape;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    public static void main(String[] args) {
        int port = 12345;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is running and waiting for a connection...");

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     ObjectInputStream objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
                     ObjectOutputStream objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream())) {

                    System.out.println("Client connected: " + clientSocket.getInetAddress());

                    // Получение объекта
                    Shape shape = (Shape) objectInputStream.readObject();
                    System.out.println("Received: " + shape);

                    // Вычисление площади
                    double area = shape.calculateArea();
                    System.out.println("Calculated area: " + area);

                    // Отправка результата клиенту
                    objectOutputStream.writeObject("The area is: " + area);

                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error while processing client: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Server failed to start: " + e.getMessage());
        }
    }
}